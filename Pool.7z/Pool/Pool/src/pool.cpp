#include "pool.h"
#include <iostream>
//A pool object will include penjing and a vector of fishes


using namespace std;
Pool::Pool(int h, int w)
{
    h_ = h;
    w_ = w;
}

// Add penjing to the pool
// legalPos is a list of possible positions for fishes to move, it will be in side the pool but outside the penjing 
void Pool::setP(Penjing p)
{
    p_=p;
    for (int i =0 ;i<=h_; i++)
        for (int j =0 ;j<=w_; j++)
        {
            Position pos(i,j);
            if (!p.checkPointInside(pos))
                legalPos.push_back(pos);
        }    
}

void Pool::show()
{

    cout << "Fishes : "<<fishes.size()<<endl;

    for (auto i : fishes)
    {
        cout << i->name() << " with Pos :" <<i->getPos().x << ","<< i->getPos().y << " and  strength: " << i->getStrength()<< endl;
    }
    cout <<"---------------------------------------------------------------"<<endl;
}

//Add fish to the list of fishes
void Pool::addFish(Fish *f)
{
    if(f)
        fishes.push_back(f);
}

//Check if fishes meet each other, the stronger one eat weaker one
void Pool::fight ()
{
    if(fishes.size() <=1)
        return;
    
    vector<Fish*>::iterator it,it2; 
    for (it =fishes.begin();it!=fishes.end()-1;it++)
       for (it2 =it+1;it2 !=fishes.end();it2++) 
        {
            if(!(*it) || !(*it2))
                return;
            if ((*it)->getPos() ==(*it2)->getPos() )
            {    
                if ((*it)->getStrength() >= (*it2)->getStrength())
                {
                    (*it)->eat(*it2);
                    fishes.erase(it2);
                }
                else 
                {
                    (*it2)->eat(*it);
                    fishes.erase(it);
                }
                it--;
                break;
            }
        }
}

//Every fish in pool makes move, check if is there any died fish (strength <0) the remove it
void Pool::makeMove()
{
    for (auto it =fishes.begin();it!=fishes.end();it++)
    {
        (*it)->move(legalPos);
        if((*it)->getStrength() <=0)
            fishes.erase(it);
    }   
}


