#include "fish.h"
#include <stdlib.h> 
#include <unistd.h>
#include <vector>
#include <algorithm>


class Shark: public Fish
{
    public :

        Shark ()
        {
            this->strength = SHARK;
        }
        Shark (int x,int y )
        {
            this->pos.x= x;
            this->pos.y= y;
            this->strength = SHARK;
        }
        std::string name()
        {
            return "Shark";
        }
        
        /*Each fish has beginning strength SHARK, and its strength decreases by SHARKRATE % after each move
        Shark move randomly up down left or right with step in range [0,2]*/
        void move(std::vector<Position> p)
        {
            Position r(-1,-1);
            while(std::find(p.begin(),p.end(),r)==p.end())
            {
                auto f = []{return (rand() % 3) * (rand() & 1 ? 1 : -1);};
                int dx = f();
                int dy = f();
                r.x =this->pos.x +dx;
                r.y =this->pos.y +dy; 
            } 
            this->pos= r;
            this->strength -= SHARK*SHARKRATE*0.01 ;

        }

};
