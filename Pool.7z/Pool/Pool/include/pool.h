#include <vector>
#include "fish.h"
#include "penjing.h"

using namespace std;
class Pool
{
    public:     
        Pool(int,int);
        int getH()
        {
            return h_;
        }
        int getW()
        {
            return w_;
        }
        vector<Fish*> getFishes()
        {
            return fishes;
        }
        void setP(Penjing);
        void addFish(Fish *);
        void show();
        void fight();
        void makeMove();


    private :
        int h_;
        int w_;
        Penjing p_ ;
        vector<Fish*> fishes;
        vector<Position> legalPos;

        
};
