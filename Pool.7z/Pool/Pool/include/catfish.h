#include "fish.h"
#include <stdlib.h> 
#include <unistd.h>
#include <vector>
#include <algorithm>


class CatFish: public Fish
{
    public :
        CatFish ()
        {
            this->strength = CATFISH;
        }
        CatFish (int x,int y )
        {
            this->pos.x= x;
            this->pos.y= y;
            this->strength = CATFISH;
        }
        std::string name()
        {
            return "Cat Fish";
        }
        
        /*Each fish has beginning strength CATFISH, and its strength decreases by CATFISHRATE % after each move
        Cat fish move randomly up down left or right with step in range [0,1]*/
        void move(std::vector<Position> p)
        {
            Position r(-1,-1);
            while(std::find(p.begin(),p.end(),r)==p.end())
            {
                auto f = []{return (rand() % 2) * (rand() & 1 ? 1 : -1);};
                int dx = f();
                int dy = f();
                r.x =this->pos.x +dx;
                r.y =this->pos.y +dy; 
            } 
            this->pos= r;
            this->strength -= CATFISH*CATFISHRATE*0.01 ;

        }

};
